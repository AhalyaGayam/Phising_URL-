import pandas as pd
from xgboost import XGBClassifier
import pickle

# Load dataset
df = pd.read_csv("merged_phishing_dataset.csv")

# Features and label
X = df.drop("class", axis=1)

# 🔥 Convert to binary (BEST)
y = df["class"].map({
    -1: 0,   # phishing
     0: 0,   # suspicious
     1: 1    # safe
})

print("Class distribution:\n", y.value_counts())

# Train model
model = XGBClassifier(
    eval_metric='logloss'
)

model.fit(X, y)

# Save
pickle.dump(model, open("XGBoost.pkl", "wb"))

print("✅ Model trained successfully")