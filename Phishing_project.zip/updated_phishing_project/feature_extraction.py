import re
import numpy as np
import requests
import os
from urllib.parse import urlparse
from dotenv import load_dotenv

load_dotenv()
API_KEY = os.getenv("770714531396dd5686e40dbbb655a40ec8dec1ba9e2c68f055083126eaa102fa")


# -------------------------
# VirusTotal API
# -------------------------
def get_virustotal_data(url):
    try:
        headers = {"x-apikey": API_KEY}

        response = requests.post(
            "https://www.virustotal.com/api/v3/urls",
            headers=headers,
            data={"url": url}
        )

        analysis_id = response.json()["data"]["id"]

        report = requests.get(
            f"https://www.virustotal.com/api/v3/analyses/{analysis_id}",
            headers=headers
        ).json()

        stats = report["data"]["attributes"]["stats"]

        return stats.get("malicious", 0), stats.get("suspicious", 0)

    except:
        return 0, 0


# -------------------------
# Feature Extraction
# -------------------------
def extract_features(url):
    features = []

    parsed = urlparse(url)
    domain = parsed.netloc
    path = parsed.path

    malicious, suspicious = get_virustotal_data(url)

    # 1 AbnormalURL
    features.append(1 if "@" in url else 0)

    # 2 AgeofDomain (approx)
    features.append(1 if len(domain) < 15 else 0)

    # 3 AnchorURL
    features.append(1 if "<a>" in url else 0)

    # 4 Blacklist_Flag (VT)
    features.append(1 if malicious > 0 else 0)

    # 5 DNSRecording
    features.append(1 if domain else 0)

    # 6 DNS Resolution Time (approx)
    features.append(len(domain))

    # 7 DisableRightClick
    features.append(0)

    # 8 DomainRegLen
    features.append(len(domain))

    # 9 Domain Age Days (approx)
    features.append(len(domain) * 2)

    # 10 Domain Expiry Days (approx)
    features.append(len(domain) * 3)

    # 11 External Link Ratio
    features.append(url.count("http"))

    # 12 Favicon
    features.append(1 if "favicon" in url else 0)

    # 13 GoogleIndex (approx)
    features.append(1 if malicious == 0 else 0)

    # 14 HTTPS
    features.append(1 if url.startswith("https") else 0)

    # 15 HTTPSDomainURL
    features.append(1 if "https" in domain else 0)

    # 16 Hidden Elements
    features.append(1 if "%00" in url else 0)

    # 17 JS Events
    features.append(1 if "javascript" in url.lower() else 0)

    # 18 Suspicious Words
    suspicious_words = ["login","verify","bank","secure","account","update"]
    features.append(1 if any(w in url.lower() for w in suspicious_words) else 0)

    # 19 IframeRedirection
    features.append(1 if "iframe" in url.lower() else 0)

    # 20 Iframe Depth
    features.append(url.count("iframe"))

    # 21 Index
    features.append(1 if "index" in url else 0)

    # 22 InfoEmail
    features.append(1 if "mailto" in url else 0)

    # 23 LinksInScriptTags
    features.append(url.count("<script"))

    # 24 LinksPointingToPage
    features.append(url.count("href"))

    # 25 LongURL
    features.append(1 if len(url) > 75 else 0)

    # 26 NonStdPort
    features.append(1 if ":" in domain else 0)

    # 27 Num_Dots
    features.append(url.count("."))

    # 28 Num_Forms
    features.append(url.count("<form"))

    # 29 Num_Special_Chars
    features.append(len(re.findall(r"[@#$%^&*]", url)))

    # 30 PageRank (approx)
    features.append(1 if malicious == 0 else 0)

    # 31 PrefixSuffix-
    features.append(1 if "-" in domain else 0)

    # 32 Redirecting//
    features.append(1 if "//" in url[8:] else 0)

    # 33 RequestURL
    features.append(url.count("http"))

    # 34 SSL Issuer Trusted
    features.append(1 if malicious == 0 else 0)

    # 35 SSL Valid
    features.append(1 if url.startswith("https") else 0)

    # 36 ServerFormHandler
    features.append(1 if "action" in url else 0)

    # 37 ShortURL
    shorteners = ["bit.ly","tinyurl","goo.gl"]
    features.append(1 if any(s in url for s in shorteners) else 0)

    # 38 StatsReport
    features.append(suspicious)

    # 39 StatusBarCust
    features.append(1 if "status" in url else 0)

    # 40 SubDomains
    features.append(domain.count("."))

    # 41 Symbol@
    features.append(1 if "@" in url else 0)

    # 42 URL Entropy
    features.append(len(set(url)) / len(url))

    # 43 URL Length
    features.append(len(url))

    # 44 UsingIP
    features.append(1 if re.match(r'\d+\.\d+\.\d+\.\d+', domain) else 0)

    # 45 UsingPopupWindow
    features.append(1 if "popup" in url else 0)

    # 46 WebsiteForwarding
    features.append(url.count("//"))

    # 47 WebsiteTraffic (VT)
    features.append(malicious + suspicious)

    return np.array(features)