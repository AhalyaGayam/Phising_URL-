from flask import Flask, request, render_template
import pickle
from feature_extraction import extract_features, get_virustotal_data

app = Flask(__name__)

model = pickle.load(open("XGBoost.pkl", "rb"))


@app.route('/')
def home():
    return render_template("index.html")


@app.route('/predict', methods=['POST'])
def predict():
    url = request.form['url']

    # 🔥 RULE-BASED CHECK
    if any(word in url.lower() for word in ["login", "verify", "@", "bank"]):
        return render_template("index.html",
            prediction="PHISHING 🚫 (Rule-based)",
            url=url,
            confidence="High"
        )

    # Feature extraction
    features = extract_features(url)

    # ML prediction
    probs = model.predict_proba([features])[0]
    confidence = round(probs[1] * 100, 2)

    # VirusTotal check
    malicious, suspicious = get_virustotal_data(url)

    # 🔥 FINAL DECISION
    if malicious > 0:
        result = "PHISHING 🚫 (VirusTotal)"
    elif probs[1] < 0.5:
        result = "PHISHING 🚫"
    elif confidence < 70:
        result = "SUSPICIOUS ⚠️"
    else:
        result = "SAFE ✅"

    return render_template(
        "index.html",
        prediction=result,
        url=url,
        confidence=confidence
    )


if __name__ == "__main__":
    app.run(debug=True)